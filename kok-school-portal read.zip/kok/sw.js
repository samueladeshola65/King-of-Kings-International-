const V='kok-v2';
const CORE=['index.html','portal.html','about.html','academics.html','admissions.html','gallery.html','news.html','contact.html','student.html','parent.html','teacher.html','admin.html','assets/css/style.css','assets/js/app.js','assets/js/portal.js','assets/img/building.jpg','assets/img/event1.jpg','assets/img/event2.jpg','assets/img/crest.jpg','assets/img/badge.jpg','assets/icons/icon-192.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const u=new URL(e.request.url); if(u.origin!==location.origin)return;
  e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(V).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request,{ignoreSearch:true})));
});
