/* King of Kings International School: KOK Assistant (demo)
   A site guide for parents, students and visitors. It answers simple questions from the school's own
   content and sends people to the right page. It runs fully in the browser, no server and no API key.
   In the live version it can be connected to the school's records and a real AI model. */
(function () {
  'use strict';
  if (window.__kokAssistant) return;
  window.__kokAssistant = true;

  var PHONE = '0805 510 1414', TEL = 'tel:08055101414';
  var SKEY = 'kok_chat_v1', OKEY = 'kok_chat_open';

  /* ---------- helpers ---------- */
  function K() { try { return typeof KOK !== 'undefined' ? KOK : null; } catch (e) { return null; } }
  function naira(n) { return '₦' + Number(n || 0).toLocaleString('en-NG'); }
  function user() { var k = K(); try { return k && k.user ? k.user() : null; } catch (e) { return null; } }
  function sget(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function sset(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  function norm(s) {
    return ' ' + String(s).toLowerCase()
      .replace(/[‘’']/g, '')
      .replace(/[^a-z0-9₦ ]+/g, ' ')
      .replace(/\s+/g, ' ').trim() + ' ';
  }
  function portalLink(role, view, label) {
    var u = user();
    var page = { parent: 'parent.html', student: 'student.html', teacher: 'teacher.html', admin: 'admin.html' }[role];
    if (u && u.role === role) return [label, page + (view ? '#' + view : '')];
    return ['Open portal login', 'portal.html'];
  }

  /* ---------- class fee lookup ---------- */
  function findClass(q) {
    var m;
    if ((m = q.match(/\bnursery ?([12])\b/))) return 'Nursery ' + m[1];
    if ((m = q.match(/\bprimary ?([1-6])\b/)) || (m = q.match(/\bp ?([1-6])\b/))) return 'Primary ' + m[1];
    if ((m = q.match(/\bjss ?([1-3])\b/)) || (m = q.match(/\bjunior (?:college |secondary )?([1-3])\b/))) return 'JSS ' + m[1];
    if ((m = q.match(/\bss ?([1-3]) ?(science|art)?\b/)) || (m = q.match(/\bsenior (?:college |secondary )?([1-3]) ?(science|art)?\b/))) {
      return 'SS ' + m[1] + ' ' + ((m[2] || 'science').charAt(0).toUpperCase() + (m[2] || 'science').slice(1));
    }
    return null;
  }
  function feeAnswer(cls) {
    var k = K();
    if (!k || !k.feeItems) return null;
    var items = k.feeItems(cls), total = 0, lines = [];
    items.forEach(function (it) { total += it[1]; lines.push(it[0] + ': ' + naira(it[1])); });
    return {
      t: 'Here is the sample fee breakdown for ' + cls + ' per term:\n' + lines.join('\n') + '\nTotal with every item: ' + naira(total) +
         '\nTuition alone is ' + naira(k.tuitionFor(cls)) + '. Bus and lunch are optional and billed separately. These are sample amounts for this prototype.',
      l: [['Fee guide', 'admissions.html'], portalLink('parent', 'pay', 'Pay fees online')],
      c: ['How do I pay fees?', 'How do I apply?']
    };
  }

  /* ---------- knowledge base ---------- */
  var KB = [
    { id: 'greet', k: ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'how far', 'good day', 'hiya', 'sup'],
      a: function () { return { t: 'Hello, welcome to King of Kings International School. I can help with admissions, fees, results, the parent and student portals, news and contact details. What would you like to know?', c: ['How do I apply?', 'School fees', 'Pay fees online', 'Portal login help'] }; } },

    { id: 'thanks', k: ['thanks', 'thank you', 'thank u', 'tnx', 'thx', 'much appreciated', 'well done', 'nice one'],
      a: function () { return { t: 'You are welcome. Is there anything else I can help you find?', c: ['School fees', 'Contact the school', 'Latest news'] }; } },

    { id: 'bye', k: ['bye', 'goodbye', 'see you', 'good night', 'later', 'ok bye'],
      a: function () { return { t: 'Goodbye, and have a lovely day. I am here whenever you need me.' }; } },

    { id: 'help', k: ['help', 'what can you do', 'menu', 'options', 'who are you', 'what are you', 'are you a robot', 'are you ai', 'are you real', 'your name'],
      a: function () { return { t: 'I am the King of Kings school assistant, a demo AI guide. I can answer simple questions about admissions, fees, classes, results, the portals, school news and how to reach the school, and I will point you to the right page. For anything personal like a child\'s record, please use the portal or call the office.', c: ['How do I apply?', 'School fees', 'Where is the school?', 'Portal login help'] }; } },

    { id: 'about', k: ['about', 'about the school', 'about school', 'history', 'mission', 'vision', 'values', 'motto', 'tell me about', 'what is king of kings', 'secular', 'coeducational', 'co educational', 'day school', 'boarding'],
      a: function () { return { t: 'King of Kings International School in Ibadan is a caring, coeducational day school for children from Creche to College. We follow a British American curriculum in a secular environment, and our motto is Dedicated to Excellence. Our core values are excellence, discipline, etiquette, curiosity and care for others. We do not run boarding, we are a day school.', l: [['About the school', 'about.html'], ['See the gallery', 'gallery.html']], c: ['What classes do you have?', 'How do I apply?'] }; } },

    { id: 'apply', k: ['admission', 'admissions', 'apply', 'application', 'enrol', 'enroll', 'enrolment', 'register my child', 'new student', 'new pupil', 'join the school', 'get admitted', 'admit', 'entrance', 'assessment', 'requirements', 'how to join', 'start application', 'registration'],
      a: function () { return { t: 'Admission is four simple steps. One, fill the online application form. Two, visit the school and meet the Head. Three, your child takes a friendly entrance assessment. Four, you receive an offer, pay fees and get portal access. The office calls within two working days of your application.', l: [['Start application', 'admissions.html'], ['Book a school tour', 'contact.html']], c: ['School fees', 'Book a school tour', 'What classes do you have?'] }; } },

    { id: 'fees', k: ['fee', 'fees', 'tuition', 'school fees', 'how much', 'cost', 'price', 'charges', 'charge', 'amount', 'fee guide', 'fee structure', 'per term', 'expensive'],
      a: function () {
        var k = K(), ex = '';
        if (k && k.tuitionFor) ex = ' For example, tuition is ' + naira(k.tuitionFor('Nursery 1')) + ' for Nursery 1, ' + naira(k.tuitionFor('Primary 5')) + ' for Primary 5, ' + naira(k.tuitionFor('JSS 2')) + ' for JSS 2 and ' + naira(k.tuitionFor('SS 1 Science')) + ' for SS 1 Science.';
        return { t: 'Tuition ranges from ' + naira(50000) + ' to ' + naira(150000) + ' per term depending on class.' + ex + ' Optional items such as bus and lunch are billed separately. These figures are samples for this prototype. Tell me a class, for example Primary 3 or SS 2 Art, and I will show the full breakdown.', l: [['Fee guide', 'admissions.html']], c: ['Primary 3 fees', 'JSS 1 fees', 'How do I pay fees?'] };
      } },

    { id: 'pay', k: ['pay', 'payment', 'pay fees', 'pay online', 'paying', 'receipt', 'invoice', 'balance', 'outstanding', 'owe', 'part payment', 'installment', 'instalment', 'card', 'bank transfer', 'ussd', 'paystack', 'flutterwave', 'payment history', 'how do i pay'],
      a: function () { return { t: 'Parents pay from the Parent Portal. Sign in, open Pay School Fees, choose the child and the fee items, then pay by card, bank transfer or USSD. You can pay in full or part pay each item, and you get an instant receipt that is saved in Payment History. In this demo payments are simulated and no money moves.', l: [portalLink('parent', 'pay', 'Pay school fees'), portalLink('parent', 'history', 'View payment history')], c: ['Portal login help', 'School fees'] }; } },

    { id: 'results', k: ['result', 'results', 'score', 'scores', 'grade', 'grades', 'report card', 'report', 'position', 'mid term result', 'exam result', 'performance', 'how is my child doing', 'marks', 'broadsheet', 'published', 'where do i see results', 'see results', 'check results'],
      a: function () { return { t: 'Results appear on the dashboard as soon as the school publishes them. Parents open Results in the Parent Portal and students open Results in the Student Portal. You will see mid term scores, exam results, grades and class position. If a result is not showing yet, the school has not published it, so please check again later or call the office.', l: [portalLink('parent', 'results', 'Parent results'), portalLink('student', 'results', 'Student results')], c: ['Portal login help', 'Contact the school'] }; } },

    { id: 'login', k: ['login', 'log in', 'sign in', 'signin', 'portal', 'password', 'forgot', 'forget', 'forgotten', 'cant login', 'cannot login', 'access', 'username', 'my id', 'account', 'reset', 'locked out', 'portal help'],
      a: function () { return { t: 'Open Portal Login, pick your section (Primary School or College), then your role: Parent, Student, Teacher or Leadership. Enter your ID and password and tap Sign in. Students use their admission number, for example KKI/P/001. If you forgot your password or cannot sign in, please call the office on ' + PHONE + ' and they will help you.', l: [['Open portal login', 'portal.html'], ['Call the office', TEL]], c: ['Show demo accounts', 'How do I pay fees?'] }; } },

    { id: 'demo', k: ['demo', 'demo account', 'demo accounts', 'test account', 'sample login', 'sample account', 'try the portal', 'try portal', 'demo login', 'demo password', 'show demo'],
      a: function () { return { t: 'This is a prototype, so you can try the portals with demo accounts. The password for every demo account is demo123.\nParent: par1 (two children), par2, par3\nStudent: KKI/P/001 (Primary 4), KKI/C/001 (JSS 2)\nTeacher: T001 (Primary), T003 (College)\nLeadership: HT01 Head Teacher, PR01 Principal, BU01 Bursar, PO01 Proprietor', l: [['Open portal login', 'portal.html']], c: ['How do I pay fees?', 'Where do I see results?'] }; } },

    { id: 'contact', k: ['contact', 'phone', 'call', 'number', 'email', 'reach', 'whatsapp', 'speak', 'talk', 'human', 'someone', 'staff', 'office', 'hours', 'open', 'opening', 'closing', 'working hours', 'office hours', 'message', 'complain', 'complaint', 'enquiry', 'inquiry'],
      a: function () { return { t: 'You can reach the school office on ' + PHONE + '. Office hours are Monday to Friday, 8:00 am to 4:00 pm. You can also send a message from the Contact page for admission enquiries, school tours, fees and payment or portal help, and the office will get back to you.', l: [['Send a message', 'contact.html'], ['Call the office', TEL]], c: ['Where is the school?', 'Book a school tour'] }; } },

    { id: 'location', k: ['address', 'location', 'where', 'directions', 'direction', 'find you', 'map', 'located', 'olorunda', 'eniosa', 'ibadan', 'how do i get', 'landmark', 'route', 'oyo'],
      a: function () { return { t: 'We are at km 1, off Eniosa Road, Olorunda Abaa, Olorunda, Ibadan, Oyo State. Direction: after Maatan Hotel and Suites, by N.O. Idowu Comprehensive Secondary School.', l: [['Contact and directions', 'contact.html'], ['Call for directions', TEL]], c: ['Book a school tour', 'Office hours'] }; } },

    { id: 'tour', k: ['tour', 'visit', 'see the school', 'book a visit', 'school visit', 'inspect', 'inspection', 'come and see', 'appointment', 'meet the head', 'book tour', 'book a tour'],
      a: function () { return { t: 'We would love to show you around. Send a message on the Contact page and choose Book a school tour as the reason, or call ' + PHONE + '. A school visit is also part of the admission steps, where you tour the campus and meet the Head.', l: [['Book a school tour', 'contact.html'], ['Call the office', TEL]], c: ['How do I apply?', 'Where is the school?'] }; } },

    { id: 'academics', k: ['curriculum', 'academics', 'academic', 'subjects', 'subject', 'british', 'american', 'syllabus', 'classes', 'class', 'levels', 'sections', 'section', 'primary', 'college', 'junior', 'senior', 'jss', 'ss', 'nursery', 'creche', 'daycare', 'day care', 'preschool', 'pre nursery', 'toddler', 'science', 'art', 'age', 'ages', 'what classes', 'which classes', 'after school', 'waec', 'neco'],
      a: function () { return { t: 'We teach from Creche and Daycare through Preschool, Pre Nursery and Nursery, then Primary 1 to 6. The College has Junior College (JSS 1 to 3) and Senior College (SS 1 to 3) with Science and Art departments. We follow a British American curriculum. Primary subjects include core subjects plus French, ICT, music and Yoruba. We also run an After School programme.', l: [['Academics', 'academics.html']], c: ['How do I apply?', 'School fees', 'Clubs and activities'] }; } },

    { id: 'facilities', k: ['facilities', 'facility', 'library', 'lab', 'laboratory', 'ict', 'computer', 'computers', 'pool', 'swimming pool', 'canteen', 'lunch', 'meals', 'food', 'sick bay', 'clinic', 'nurse', 'hall', 'whiteboard', 'playground', 'sports complex', 'bus', 'school bus', 'transport', 'pick up', 'drop off', 'campus'],
      a: function () { return { t: 'Our campus has nine facilities: a standard ICT Centre, a Library, a Laboratory, Interactive Whiteboards, a Sports Complex and Playground with swimming, a School Bus for safe pick up and drop off, a Lunch Programme with balanced meals, a Sick Bay and a Multipurpose Hall. Bus and lunch are optional and billed separately.', l: [['Facilities on the home page', 'index.html'], ['Gallery', 'gallery.html']], c: ['School fees', 'Clubs and activities'] }; } },

    { id: 'clubs', k: ['club', 'clubs', 'activity', 'activities', 'extra curricular', 'extracurricular', 'sports', 'sport', 'music', 'drama', 'chess', 'ballet', 'dance', 'debate', 'jets', 'scrabble', 'spelling bee', 'entrepreneur', 'french', 'languages', 'etiquette', 'excursion', 'field trip', 'inter house', 'costume day'],
      a: function () { return { t: 'Children can join clubs and societies including Swimming, Chess, Ballet, Music and Drama, Debate and Press, Scrabble, JETS, Entrepreneur Club, Foreign Languages and Spelling Bee. There are also special music classes, etiquette, dance, local excursions and field trips, Inter House Sports and Costume Day.', l: [['About the school', 'about.html'], ['News and events', 'news.html']], c: ['Latest news', 'What classes do you have?'] }; } },

    { id: 'news', k: ['news', 'event', 'events', 'holiday', 'break', 'resume', 'resumption', 'vacation', 'mid term', 'midterm', 'calendar', 'sports day', 'prize giving', 'prize day', 'award', 'happening', 'when does school', 'when is', 'term dates', 'latest'],
      a: function () { return { t: 'Here is what is coming up. Mid term break holds from 29 October to 2 November, and classes resume on 3 November. Inter House Sports is in November 2026 and parents are invited to cheer. Prize and Award Giving Day is in December 2026. Costume and Activity Day happened in October.', l: [['News and events', 'news.html']], c: ['Contact the school', 'Gallery'] }; } },

    { id: 'gallery', k: ['gallery', 'photo', 'photos', 'picture', 'pictures', 'images', 'image', 'pics', 'crest', 'badge', 'campus photos'],
      a: function () { return { t: 'You can see real photos of our campus, activity day, dance and music sessions, our crest and the uniform badge in the gallery. More albums will be added as the school uploads them.', l: [['Open the gallery', 'gallery.html']], c: ['Book a school tour', 'Latest news'] }; } },

    { id: 'teacher', k: ['teacher', 'teachers', 'score entry', 'enter scores', 'upload scores', 'staff login', 'teacher login', 'teacher portal', 'record scores', 'my classes'],
      a: function () { return { t: 'Teachers sign in through Portal Login and choose Teacher. In Score Entry they record test and exam scores on a simple sheet, and grades are calculated automatically. My Classes shows each class they teach.', l: [['Teacher login', 'portal.html'], portalLink('teacher', 'scores', 'Open score entry')], c: ['Show demo accounts'] }; } },

    { id: 'student', k: ['student portal', 'my timetable', 'timetable', 'my subjects', 'student login', 'pupil', 'my fees', 'student dashboard', 'i am a student', 'im a student'],
      a: function () { return { t: 'Students sign in with their admission number, for example KKI/P/001. The Student Portal shows Overview, Results, School Fees, My Subjects, Timetable and Notices.', l: [['Student login', 'portal.html'], portalLink('student', 'timetable', 'Open timetable')], c: ['Show demo accounts', 'Where do I see results?'] }; } },

    { id: 'leadership', k: ['principal', 'head teacher', 'headteacher', 'bursar', 'proprietor', 'leadership', 'admin', 'administrator', 'applications', 'results control', 'publish results', 'management', 'dashboard'],
      a: function () { return { t: 'Leaders sign in as Leadership. The Head Teacher, Principal, Bursar and Proprietor can track fee collection and outstanding balances, control when results are published, review new applications, post announcements and see staff. In this demo, BU01 is the Bursar and HT01 is the Head Teacher, with password demo123.', l: [['Leadership login', 'portal.html'], portalLink('admin', '', 'Open leadership dashboard')], c: ['Show demo accounts'] }; } },

    { id: 'discount', k: ['scholarship', 'scholarships', 'discount', 'sibling', 'siblings', 'waiver', 'bursary', 'free', 'reduce', 'reduction', 'cheaper', 'concession'],
      a: function () { return { t: 'A scholarship is not available at the moment. A siblings discount is not stated on the website, so please ask the office to confirm on ' + PHONE + '.', l: [['Send a message', 'contact.html'], ['Call the office', TEL]], c: ['School fees', 'Contact the school'] }; } },

    { id: 'uniform', k: ['uniform', 'uniforms', 'textbook', 'textbooks', 'books', 'stationery', 'school wear', 'sandals', 'sportswear', 'what to bring', 'school bag'],
      a: function () { return { t: 'Books and Stationery is a fee item in the portal, and our uniform carries the embroidered crest badge. Uniform prices and the full list of what to bring are not on the website, so please ask the office on ' + PHONE + ' or send a message.', l: [['Send a message', 'contact.html'], ['Fee guide', 'admissions.html']], c: ['School fees', 'Contact the school'] }; } },

    { id: 'install', k: ['install', 'app', 'phone app', 'download', 'add to home screen', 'mobile app', 'android', 'iphone', 'ios', 'offline'],
      a: function () { return { t: 'You can install the portal as a phone app. Open the Portal Login page on your phone and tap Install the portal as an app, or use your browser menu and choose Add to Home Screen. The site is built to be light and fast on any phone.', l: [['Open portal login', 'portal.html']], c: ['Portal login help'] }; } },

    { id: 'built', k: ['built', 'who built', 'who made', 'developer', 'gloxadx', 'gloxad', 'designed', 'created', 'website designer', 'who designed'],
      a: function () { return { t: 'This website and portal prototype were designed by GloxadX.', c: ['What can you do?'] }; } }
  ];

  /* ---------- matching ---------- */
  function score(q, tokens, item) {
    var s = 0;
    for (var i = 0; i < item.k.length; i++) {
      var kw = item.k[i], nk = norm(kw);
      if (kw.indexOf(' ') > -1) { if (q.indexOf(nk) > -1) s += 4; }
      else if (tokens.indexOf(kw) > -1) s += (kw.length <= 2 ? 1.5 : 2);
      else if (kw.length >= 5) {
        for (var j = 0; j < tokens.length; j++) {
          var t = tokens[j];
          if (t.length >= 5 && (t.indexOf(kw) === 0 || kw.indexOf(t) === 0)) { s += 1; break; }
        }
      }
    }
    return s;
  }
  var misses = 0;
  function reply(raw) {
    var q = norm(raw), tokens = q.trim().split(' ');
    var cls = findClass(q);
    if (cls && /(fee|fees|tuition|cost|price|how much|pay|charge|amount|school fees)/.test(q)) {
      var fa = feeAnswer(cls); if (fa) { misses = 0; return fa; }
    }
    if (cls && /(subject|subjects|learn|study|taught|teach|offer|curriculum|syllabus)/.test(q)) {
      var k = K();
      if (k && k.subjectsFor) {
        misses = 0;
        return { t: 'Subjects for ' + cls + ' include ' + k.subjectsFor(cls).join(', ') + '. These come from the school portal sample data for this prototype.',
          l: [['Academics', 'academics.html']], c: [cls + ' fees', 'How do I apply?'] };
      }
    }
    var best = null, bs = 0, second = 0;
    for (var i = 0; i < KB.length; i++) {
      var sc = score(q, tokens, KB[i]);
      if (sc > bs) { second = bs; bs = sc; best = KB[i]; } else if (sc > second) { second = sc; }
    }
    if (cls && (!best || bs < 4)) {
      return { t: cls + ' is part of our ' + (cls.indexOf('Nursery') === 0 || cls.indexOf('Primary') === 0 ? 'Primary School' : 'College') + '. Would you like the fees for it, or to start an application?', c: [cls + ' fees', 'How do I apply?'] };
    }
    if (best && bs >= 2) { misses = 0; return best.a(); }
    misses++;
    var t = 'I am not sure I understood that. You can ask me about admissions, fees, classes, results, the portals, school news, or where to find us.';
    if (misses >= 2) t += ' For anything else, our office is happy to help on ' + PHONE + ', Monday to Friday, 8:00 am to 4:00 pm.';
    return { t: t, l: misses >= 2 ? [['Call the office', TEL], ['Send a message', 'contact.html']] : [], c: ['How do I apply?', 'School fees', 'Portal login help', 'Contact the school'] };
  }

  /* ---------- UI ---------- */
  var css =
    '#kok-ai-fab{position:fixed;right:16px;bottom:16px;z-index:2147482000;display:flex;align-items:center;gap:8px;border:0;cursor:pointer;background:linear-gradient(135deg,#2b8c52,#145233);color:#fff;font:700 14px/1 inherit;font-family:inherit;padding:13px 18px 13px 14px;border-radius:99px;box-shadow:0 12px 28px -8px rgba(20,82,51,.65);transition:transform .2s,box-shadow .2s}' +
    '#kok-ai-fab:hover{transform:translateY(-2px)}#kok-ai-fab:focus-visible,#kok-ai-panel button:focus-visible,#kok-ai-panel input:focus-visible,#kok-ai-panel a:focus-visible{outline:3px solid #f7b3c7;outline-offset:2px}' +
    '#kok-ai-fab svg{width:22px;height:22px;flex:none}#kok-ai-fab .dot{position:absolute;top:-2px;right:-2px;width:12px;height:12px;border-radius:50%;background:#f7b3c7;border:2px solid #fff}' +
    '#kok-ai-panel,#kok-ai-panel *{box-sizing:border-box}#kok-ai-panel{position:fixed;right:16px;bottom:16px;z-index:2147482001;width:380px;max-width:calc(100vw - 24px);height:min(600px,calc(100vh - 32px));display:none;flex-direction:column;background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 30px 70px -18px rgba(13,58,37,.55),0 0 0 1px rgba(20,82,51,.08);font-family:inherit;color:#0f2a1d;padding:0;margin:0;line-height:1.4;text-align:left}' +
    '#kok-ai-panel.open{display:flex;animation:kokpop .22s ease-out}@keyframes kokpop{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}' +
    '#kok-ai-panel .kai-h{display:flex;align-items:center;gap:11px;padding:14px 14px 14px 16px;background:linear-gradient(135deg,#1d6e44,#145233);color:#fff}' +
    '#kok-ai-panel .kai-h .av{width:38px;height:38px;border-radius:12px;background:#fff;display:grid;place-items:center;flex:none}' +
    '#kok-ai-panel .kai-h b{display:block;font-size:15px;line-height:1.2;color:#fff}#kok-ai-panel .kai-h small{display:flex;align-items:center;gap:6px;font-size:11.5px;opacity:.85;margin-top:2px}' +
    '#kok-ai-panel .kai-h small i{width:7px;height:7px;border-radius:50%;background:#6fcb90;display:inline-block}' +
    '#kok-ai-panel .kai-h .x{margin-left:auto;background:rgba(255,255,255,.14);border:0;color:#fff;width:34px;height:34px;border-radius:10px;cursor:pointer;font-size:18px;line-height:1}#kok-ai-panel .kai-h .x:hover{background:rgba(255,255,255,.26)}' +
    '#kok-ai-msgs{flex:1;overflow-y:auto;padding:16px 14px 8px;background:#f3fbf5;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth;overscroll-behavior:contain}' +
    '.kai-m{max-width:88%;padding:10px 13px;border-radius:16px;font-size:14px;line-height:1.5;word-wrap:break-word;overflow-wrap:anywhere}' +
    '.kai-m p{margin:0;padding:0;font-size:14px;line-height:1.5;color:inherit;max-width:none}.kai-m p+p{margin-top:5px}' +
    '.kai-b{align-self:flex-start;background:#fff;border:1px solid #e0eee5;border-bottom-left-radius:5px;box-shadow:0 2px 8px -4px rgba(20,82,51,.2)}' +
    '.kai-u{align-self:flex-end;background:#1d6e44;color:#fff;border-bottom-right-radius:5px}' +
    '.kai-links,.kai-chips{display:flex;flex-wrap:wrap;gap:7px;margin-top:9px}' +
    '.kai-links a{display:inline-flex;align-items:center;gap:5px;background:#1d6e44;color:#fff;text-decoration:none;font-weight:700;font-size:13px;padding:8px 13px;border-radius:99px}.kai-links a:hover{background:#145233}' +
    '.kai-chips button{background:#fff;border:1.5px solid #c8edd3;color:#145233;font:600 12.5px/1.2 inherit;font-family:inherit;padding:7px 12px;border-radius:99px;cursor:pointer}.kai-chips button:hover{background:#e3f6e8;border-color:#6fcb90}' +
    '.kai-typing{display:inline-flex;gap:4px;padding:12px 14px}.kai-typing i{width:7px;height:7px;border-radius:50%;background:#6fcb90;animation:kaib 1s infinite}.kai-typing i:nth-child(2){animation-delay:.15s}.kai-typing i:nth-child(3){animation-delay:.3s}@keyframes kaib{0%,60%,100%{transform:translateY(0);opacity:.5}30%{transform:translateY(-5px);opacity:1}}' +
    '#kok-ai-panel form{display:flex;gap:8px;padding:10px 12px;background:#fff;border-top:1px solid #e0eee5}' +
    '#kok-ai-panel input{flex:1;min-width:0;border:1.5px solid #c8edd3;border-radius:99px;padding:11px 15px;font:16px/1.2 inherit;font-family:inherit;background:#f3fbf5;color:#0f2a1d}#kok-ai-panel input:focus{border-color:#2b8c52;background:#fff}' +
    '#kok-ai-panel form button{flex:none;width:44px;height:44px;border-radius:50%;border:0;background:#1d6e44;color:#fff;cursor:pointer;display:grid;place-items:center}#kok-ai-panel form button:hover{background:#145233}#kok-ai-panel form button svg{width:19px;height:19px}' +
    '.kai-foot{padding:0 14px 10px;background:#fff;text-align:center;font-size:10.5px;color:#5b7a6a}' +
    '@media(max-width:980px){#kok-ai-fab{bottom:88px;right:12px}body:not(.pub):not([data-kok-ai]) #kok-ai-fab{bottom:78px}}' +
    '@media(max-width:600px){#kok-ai-panel{right:0;left:0;bottom:0;width:100%;max-width:100%;height:calc(100% - 24px);height:calc(100dvh - 24px);border-radius:22px 22px 0 0}#kok-ai-fab span.lbl{display:none}#kok-ai-fab{padding:14px}}' +
    '@media(prefers-reduced-motion:reduce){#kok-ai-panel.open{animation:none}.kai-typing i{animation:none}#kok-ai-msgs{scroll-behavior:auto}}' +
    '@media print{#kok-ai-fab,#kok-ai-panel{display:none!important}}';

  var ICON_CHAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><path d="M9 11h.01M12 11h.01M15 11h.01" stroke-width="2.6"/></svg>';
  var ICON_SEND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/></svg>';

  var fab, panel, msgs, input, history = [];

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function save() { sset(SKEY, JSON.stringify(history.slice(-30))); }
  function scroll() { msgs.scrollTop = msgs.scrollHeight; }
  function isExternal(h) { return /^(tel:|mailto:|https?:)/.test(h); }

  function render(m, animate) {
    var b = el('div', 'kai-m ' + (m.r === 'u' ? 'kai-u' : 'kai-b'));
    String(m.t).split('\n').forEach(function (line) { b.appendChild(el('p', '', line)); });
    if (m.l && m.l.length) {
      var wrap = el('div', 'kai-links'), seen = {};
      m.l.forEach(function (x) {
        var key = x[0] + '|' + x[1]; if (seen[key]) return; seen[key] = 1;
        var a = el('a', '', x[0] + (isExternal(x[1]) ? '' : ' →')); a.href = x[1];
        wrap.appendChild(a);
      });
      b.appendChild(wrap);
    }
    if (m.c && m.c.length) {
      var cw = el('div', 'kai-chips');
      m.c.forEach(function (x) { var bt = el('button', '', x); bt.type = 'button'; bt.onclick = function () { ask(x); }; cw.appendChild(bt); });
      b.appendChild(cw);
    }
    msgs.appendChild(b);
    if (animate !== false) scroll();
    return b;
  }

  function say(m, noSave) {
    history.push(m); if (!noSave) save(); return render(m);
  }

  function ask(text) {
    text = String(text || '').trim(); if (!text) return;
    clearChips();
    say({ r: 'u', t: text });
    var ty = el('div', 'kai-m kai-b'); var d = el('span', 'kai-typing'); d.setAttribute('aria-label', 'Assistant is typing');
    d.innerHTML = '<i></i><i></i><i></i>'; ty.appendChild(d); msgs.appendChild(ty); scroll();
    var r = reply(text), wait = Math.min(1100, 380 + r.t.length * 3);
    setTimeout(function () { if (ty.parentNode) ty.parentNode.removeChild(ty); r.r = 'b'; say(r); input.focus({ preventScroll: true }); }, wait);
  }

  function clearChips() {
    var all = msgs.querySelectorAll('.kai-chips'); for (var i = 0; i < all.length; i++) all[i].parentNode.removeChild(all[i]);
    history.forEach(function (m) { if (m.c) m.c = null; });
  }

  function welcome() {
    var u = user(), name = '';
    try { var w = K() && K().who ? K().who(u) : null; if (w && w.name) name = ' ' + (u && u.role === 'parent' ? w.name : w.name.split(' ')[0]); } catch (e) {}
    var hi = u ? 'Hello' + name + ', welcome back. ' : 'Hello and welcome to King of Kings International School. ';
    var chips = u && u.role === 'parent' ? ['Pay fees online', 'Where do I see results?', 'Latest news', 'Contact the school']
      : ['How do I apply?', 'School fees', 'Portal login help', 'Where is the school?'];
    say({ r: 'b', t: hi + 'I am the school assistant. Ask me a question and I will answer it and take you to the right page.\nThis is a demo AI guide. For personal records please use the portal.', c: chips });
  }

  function open() {
    panel.classList.add('open'); fab.style.display = 'none'; sset(OKEY, '1');
    if (!history.length) welcome();
    setTimeout(function () { scroll(); input.focus({ preventScroll: true }); }, 30);
  }
  function close() { panel.classList.remove('open'); fab.style.display = ''; sset(OKEY, '0'); fab.focus({ preventScroll: true }); }

  function mount() {
    if (document.getElementById('kok-ai-fab') || !document.body) return;
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

    fab = el('button', ''); fab.id = 'kok-ai-fab'; fab.type = 'button'; fab.setAttribute('aria-label', 'Open the school assistant chat');
    fab.innerHTML = ICON_CHAT + '<span class="lbl">Ask the school</span><span class="dot"></span>';

    panel = el('div', ''); panel.id = 'kok-ai-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'King of Kings school assistant');
    var crest = ''; try { crest = typeof CREST === 'function' ? CREST(26) : ''; } catch (e) {}
    panel.innerHTML = '<div class="kai-h"><div class="av">' + crest + '</div><div><b>School Assistant</b><small><i></i>Demo AI guide, online</small></div><button type="button" class="x" aria-label="Close chat">✕</button></div>' +
      '<div id="kok-ai-msgs" role="log" aria-live="polite"></div>' +
      '<form autocomplete="off"><input type="text" placeholder="Ask about fees, admission, results..." aria-label="Type your question" maxlength="200"><button type="submit" aria-label="Send">' + ICON_SEND + '</button></form>' +
      '<div class="kai-foot">Answers come from the school website. Built by GloxadX.</div>';
    document.body.appendChild(fab); document.body.appendChild(panel);
    msgs = panel.querySelector('#kok-ai-msgs'); input = panel.querySelector('input');

    fab.onclick = open;
    panel.querySelector('.x').onclick = close;
    panel.querySelector('form').onsubmit = function (e) { e.preventDefault(); var v = input.value; input.value = ''; ask(v); };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && panel.classList.contains('open')) close(); });

    try { history = JSON.parse(sget(SKEY) || '[]') || []; } catch (e) { history = []; }
    history.forEach(function (m) { render(m, false); });
    if (history.length) scroll();
    if (sget(OKEY) === '1') { panel.classList.add('open'); fab.style.display = 'none'; setTimeout(scroll, 30); }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();
})();
