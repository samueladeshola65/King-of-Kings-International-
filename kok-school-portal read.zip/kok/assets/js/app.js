/* King of Kings International School: shared layer (UI helpers + demo database in localStorage) */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');

const CREST = (w = 40) => `<svg width="${w}" height="${w * 1.1}" viewBox="0 0 100 110" xmlns="http://www.w3.org/2000/svg" aria-label="King of Kings crest">
<path d="M8 22 L50 8 L92 22 V60 C92 82 72 94 50 102 C28 94 8 82 8 60Z" fill="#f7b3c7"/>
<path d="M14 26 L50 14 L86 26 V60 C86 78 69 89 50 96 C31 89 14 78 14 60Z" fill="#2b8c52"/>
<path d="M33 30 L38 18 L44 26 L50 14 L56 26 L62 18 L67 30Z" fill="#e8c26a"/><rect x="33" y="31" width="34" height="4" rx="2" fill="#e8c26a"/>
<g fill="#fff" font-family="Bricolage Grotesque,Arial" font-weight="800" text-anchor="middle"><text x="50" y="52" font-size="13">King</text><text x="50" y="66" font-size="11">of</text><text x="50" y="81" font-size="13">Kings</text></g>
<path d="M2 90 Q50 100 98 90 L98 104 Q50 112 2 104Z" fill="#f7b3c7" opacity=".0"/></svg>`;

const KOK_NAV = [
  ['index.html', 'Home'], ['about.html', 'About'], ['academics.html', 'Academics'], ['admissions.html', 'Admissions'],
  ['gallery.html', 'Gallery'], ['news.html', 'News'], ['contact.html', 'Contact']
];

function mountSite() {
  const page = location.pathname.split('/').pop() || 'index.html';
  const h = $('#site-header');
  if (h) h.outerHTML = `<header class="nav"><div class="nav-in">
    <a class="brand" href="index.html">${CREST(38)}<div><span>King of Kings</span><small>International School</small></div></a>
    <nav class="links" id="links">${KOK_NAV.map(([u, t]) => `<a href="${u}" class="${u === page ? 'on' : ''}">${t}</a>`).join('')}
      <a href="portal.html" class="btn btn-primary btn-sm" style="color:#fff;margin-left:6px">Portal Login →</a></nav>
    <button class="burger" aria-label="Menu" onclick="$('#links').classList.toggle('open')">☰</button></div></header>`;
  if (h) {
    document.body.classList.add('pub');
    const M = [['index.html', '🏠', 'Home'], ['academics.html', '🎓', 'Academics'], ['admissions.html', '📝', 'Apply'], ['gallery.html', '🖼️', 'Gallery'], ['portal.html', '🔐', 'Portal']];
    const n = document.createElement('nav'); n.className = 'mnav'; n.setAttribute('aria-label', 'App navigation');
    n.innerHTML = M.map(([u, i, t]) => `<a href="${u}" class="${u === page ? 'on' : ''} ${u === 'portal.html' ? 'portal' : ''}"><span>${i}</span>${t}</a>`).join('');
    document.body.appendChild(n);
  }
  const f = $('#site-footer');
  if (f) f.outerHTML = `<footer><div class="wrap"><div class="fgrid">
    <div><a class="brand" href="index.html" style="color:#fff">${CREST(44)}<div><span>King of Kings</span><small style="color:var(--p300)">Dedicated to Excellence</small></div></a>
      <p style="margin-top:18px;max-width:320px">A coeducational, caring and friendly school giving every child a solid all round foundation, from Creche to College.</p></div>
    <div><h4>School</h4><a href="about.html">About Us</a><a href="academics.html">Academics</a><a href="admissions.html">Admissions</a><a href="gallery.html">Gallery</a></div>
    <div><h4>Portals</h4><a href="portal.html?s=primary">Primary Portal</a><a href="portal.html?s=college">College Portal</a><a href="portal.html">Parent Login</a><a href="portal.html">Staff Login</a></div>
    <div><h4>Find us</h4><a>km 1, off Eniosa Road, Olorunda Abaa, Olorunda, Ibadan, Oyo State</a><a href="tel:08055101414">0805 510 1414</a><a href="contact.html">Send a message</a></div></div>
    <div class="fbot"><span>© 2026 King of Kings International School. All rights reserved.</span><span>Prototype designed by GloxadX</span></div></div></footer>`;
}
function toast(msg) {
  let t = $('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('on'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('on'), 3200);
}

/* ================= DATA ================= */
const KOK = (() => {
  const KEY = 'kok_db_v2';
  const NURSERY = ['Number Work', 'Letter Work', 'Phonics', 'Rhymes and Music', 'Health Habits', 'Colouring and Craft'];
  const PRIMARY = ['English Studies', 'Mathematics', 'Basic Science', 'Social Studies', 'Civic Education', 'Phonics', 'French', 'Yoruba', 'Computer Studies', 'Creative Arts', 'Music', 'Physical and Health Education', 'Christian Religious Studies'];
  const JUNIOR = ['Mathematics', 'English Language', 'Social Studies', 'Physical and Health Education', 'Civic Education', 'Agricultural Science', 'Basic Science', 'Business Studies', 'French', 'Music', 'Phonics', 'Basic Technology', 'Christian Religious Studies', 'Yoruba'];
  const SCI = ['Mathematics', 'English Language', 'Civic Education', 'Physics', 'Chemistry', 'Data Processing', 'Biology', 'Further Mathematics', 'Geography', 'Animal Husbandry', 'Agricultural Science', 'Economics'];
  const ART = ['Mathematics', 'English Language', 'Civic Education', 'Data Processing', 'Government', 'Christian Religious Studies', 'Literature in English', 'Yoruba', 'Economics'];
  const ICON = { Math: '➗', Eng: '📖', Sci: '🔬', Soc: '🌍', Civ: '🏛️', Pho: '🔤', Fre: '🇫🇷', Yor: '🗣️', Com: '💻', Cre: '🎨', Mus: '🎵', Phy: '⚽', Chr: '✝️', Agr: '🌱', Bus: '💼', Bas: '🔧', Che: '⚗️', Bio: '🧬', Geo: '🗺️', Ani: '🐓', Eco: '📈', Gov: '⚖️', Lit: '📚', Dat: '🖥️', Fur: '➗', Num: '🔢', Let: '✏️', Rhy: '🎶', Hea: '🍎', Col: '🖍️' };
  const icon = s => ICON[s.slice(0, 3)] || '📘';
  const grade = t => t >= 75 ? ['A', 'Excellent'] : t >= 65 ? ['B', 'Very Good'] : t >= 50 ? ['C', 'Good'] : t >= 45 ? ['D', 'Fair'] : t >= 40 ? ['E', 'Pass'] : ['F', 'Fail'];

  const classes = {
    primary: ['Nursery 1', 'Nursery 2', 'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6'],
    college: ['JSS 1', 'JSS 2', 'JSS 3', 'SS 1 Science', 'SS 1 Art', 'SS 2 Science', 'SS 2 Art', 'SS 3 Science', 'SS 3 Art']
  };
  const subjectsFor = cls => cls.startsWith('Nursery') ? NURSERY : cls.startsWith('Primary') ? PRIMARY : cls.startsWith('JSS') ? JUNIOR : cls.includes('Science') ? SCI : ART;
  const tuitionFor = cls => cls.startsWith('Nursery') ? 65000 : cls.startsWith('Primary') ? (+cls.slice(-1) > 3 ? 95000 : 85000) : cls.startsWith('JSS') ? 120000 : 145000;
  const feeItems = cls => {
    const p = !(cls.startsWith('JSS') || cls.startsWith('SS'));
    return [['Tuition', tuitionFor(cls)], ['Books and Stationery', p ? 15000 : 22000], ['Lunch Programme', 18000], ['School Bus', 25000], [p ? 'ICT and Activities' : 'Laboratory and ICT', p ? 7000 : 12000]];
  };

  function rnd(seed) { let s = seed; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }

  function seed() {
    const S = [
      ['KKI/P/001', 'Tobi Adeyemi', 'Primary 4', 'primary', 'M', 'par1'],
      ['KKI/C/001', 'Femi Adeyemi', 'JSS 2', 'college', 'M', 'par1'],
      ['KKI/P/002', 'Zainab Balogun', 'Primary 2', 'primary', 'F', 'par2'],
      ['KKI/P/003', 'Chidera Okafor', 'Primary 6', 'primary', 'F', 'par3'],
      ['KKI/P/004', 'David Ogunleye', 'Nursery 2', 'primary', 'M', 'par4'],
      ['KKI/P/005', 'Samuel Olatunji', 'Primary 4', 'primary', 'M', 'par5'],
      ['KKI/P/006', 'Grace Ibrahim', 'Primary 1', 'primary', 'F', 'par6'],
      ['KKI/C/002', 'Ifeoma Eze', 'SS 1 Science', 'college', 'F', 'par3'],
      ['KKI/C/003', 'Kunle Bakare', 'SS 2 Art', 'college', 'M', 'par7'],
      ['KKI/C/004', 'Halima Yusuf', 'JSS 3', 'college', 'F', 'par8'],
      ['KKI/C/005', 'Joy Okon', 'SS 3 Science', 'college', 'F', 'par9'],
      ['KKI/C/006', 'Daniel Fashola', 'JSS 1', 'college', 'M', 'par10']
    ];
    const students = S.map(([id, name, cls, sec, g, par], i) => ({ id, name, cls, sec, g, par, attendance: 88 + (i * 7) % 12, pass: 'demo123' }));
    const parents = [
      ['par1', 'Mr and Mrs Adeyemi', '08031234567'], ['par2', 'Mrs Balogun', '08051112233'], ['par3', 'Mr Okafor', '08098765432'], ['par4', 'Mrs Ogunleye', '08122334455'],
      ['par5', 'Mr Olatunji', '07033445566'], ['par6', 'Mrs Ibrahim', '08077889900'], ['par7', 'Mr Bakare', '09011223344'], ['par8', 'Alhaji Yusuf', '08166778899'], ['par9', 'Mrs Okon', '08133221100'], ['par10', 'Mr Fashola', '08044556677']
    ].map(([id, name, phone]) => ({ id, name, phone, pass: 'demo123' }));
    const teachers = [
      { id: 'T001', name: 'Mrs Funke Alabi', sec: 'primary', title: 'Class Teacher, Primary 4', pass: 'demo123', load: [['Primary 4', 'English Studies'], ['Primary 4', 'Phonics'], ['Primary 4', 'Social Studies'], ['Primary 5', 'English Studies']] },
      { id: 'T002', name: 'Mr Ibrahim Lawal', sec: 'primary', title: 'Mathematics Teacher', pass: 'demo123', load: [['Primary 4', 'Mathematics'], ['Primary 6', 'Mathematics'], ['Primary 2', 'Mathematics']] },
      { id: 'T003', name: 'Mr Chukwuma Obi', sec: 'college', title: 'Head of Sciences', pass: 'demo123', load: [['JSS 2', 'Mathematics'], ['JSS 3', 'Mathematics'], ['SS 1 Science', 'Mathematics'], ['SS 1 Science', 'Further Mathematics'], ['SS 3 Science', 'Physics']] },
      { id: 'T004', name: 'Miss Bisi Fashola', sec: 'college', title: 'English Department', pass: 'demo123', load: [['JSS 2', 'English Language'], ['SS 2 Art', 'English Language'], ['SS 2 Art', 'Literature in English'], ['SS 1 Science', 'English Language']] }
    ];
    const staff = [
      { id: 'HT01', name: 'Mrs Adebayo Ogunbanjo', role: 'Head Teacher', sec: 'primary', scope: 'primary', pass: 'demo123' },
      { id: 'PR01', name: 'Mr Okonkwo Peters', role: 'Principal', sec: 'college', scope: 'college', pass: 'demo123' },
      { id: 'BU01', name: 'Mrs Salami Ope', role: 'Bursar', sec: 'all', scope: 'all', pass: 'demo123' },
      { id: 'PO01', name: 'Chairman, Board of Directors', role: 'Proprietor', sec: 'all', scope: 'all', pass: 'demo123' }
    ];
    // scores
    const scores = {}; // key studentId|subject => {mid, exam}
    students.forEach((s, si) => {
      const r = rnd(si * 77 + 13);
      const base = 52 + Math.floor(r() * 30);
      subjectsFor(s.cls).forEach(sub => {
        const mid = Math.max(8, Math.min(30, Math.round((base + (r() * 24 - 12)) * .3)));
        const exam = Math.max(14, Math.min(70, Math.round((base + (r() * 28 - 14)) * .7)));
        scores[s.id + '|' + sub] = { mid, exam };
      });
    });
    // payments (ledger)
    const payments = []; let n = 1000;
    const pay = (sid, par, items, method, date) => payments.push({ id: 'RCP-' + (++n), sid, par, items, total: items.reduce((a, b) => a + b[1], 0), method, date, status: 'Confirmed' });
    pay('KKI/P/001', 'par1', [['Tuition', 95000], ['Books and Stationery', 15000]], 'Card', '2026-09-14');
    pay('KKI/C/001', 'par1', [['Tuition', 60000]], 'Bank Transfer', '2026-09-14');
    pay('KKI/P/002', 'par2', feeItems('Primary 2').map(([a, b]) => [a, b]), 'Card', '2026-09-08');
    pay('KKI/P/003', 'par3', [['Tuition', 95000], ['Lunch Programme', 18000], ['School Bus', 25000]], 'USSD', '2026-09-20');
    pay('KKI/C/002', 'par3', feeItems('SS 1 Science').map(([a, b]) => [a, b]), 'Bank Transfer', '2026-09-20');
    pay('KKI/P/004', 'par4', [['Tuition', 30000]], 'Card', '2026-09-22');
    pay('KKI/P/005', 'par5', feeItems('Primary 4').map(([a, b]) => [a, b]), 'Card', '2026-09-10');
    pay('KKI/C/003', 'par7', [['Tuition', 145000], ['Books and Stationery', 22000]], 'Bank Transfer', '2026-09-25');
    pay('KKI/C/005', 'par9', feeItems('SS 3 Science').map(([a, b]) => [a, b]), 'Card', '2026-09-12');
    pay('KKI/C/004', 'par8', [['Tuition', 120000], ['Laboratory and ICT', 12000]], 'USSD', '2026-10-02');
    const announcements = [
      { id: 1, t: 'First Term Mid Term Break', b: 'Mid term break holds from Thursday 29 October to Monday 2 November 2026. Classes resume Tuesday 3 November.', to: 'all', d: '2026-10-20' },
      { id: 2, t: 'Mid Term Results Published', b: 'Mid term scores for the 2026/2027 First Term are now available on every student dashboard.', to: 'all', d: '2026-10-22' },
      { id: 3, t: 'Inter House Sports Rehearsal', b: 'Primary 3 to Primary 6 should come in their house colours on Friday for rehearsals.', to: 'primary', d: '2026-10-19' },
      { id: 4, t: 'SS 3 Mock Examination Timetable', b: 'The SS 3 mock timetable is out. Collect printed copies from the Principal\'s office.', to: 'college', d: '2026-10-18' },
      { id: 5, t: 'Outstanding Fees Reminder', b: 'Parents with outstanding balances are kindly reminded to clear them before examinations begin.', to: 'parents', d: '2026-10-21' }
    ];
    return { v: 2, term: 'First Term', session: '2026/2027', students, parents, teachers, staff, scores, payments, announcements, applications: [], published: { primary: { mid: true, exam: true }, college: { mid: true, exam: true } }, nextId: 2000 };
  }

  function load() { try { const d = JSON.parse(localStorage.getItem(KEY)); if (d && d.v === 2) return d; } catch (e) { } const d = seed(); save(d); return d; }
  function save(d) { localStorage.setItem(KEY, JSON.stringify(d || db)); }
  let db = load();

  const api = {
    get db() { return db; }, grade, icon, classes, subjectsFor, feeItems, tuitionFor, save: () => save(db),
    reset() { localStorage.removeItem(KEY); sessionStorage.removeItem('kok_user'); db = seed(); save(db); },
    user() { try { return JSON.parse(sessionStorage.getItem('kok_user')); } catch (e) { return null; } },
    login(role, id, pass) {
      const pool = { student: db.students, parent: db.parents, teacher: db.teachers, admin: db.staff }[role] || [];
      const u = pool.find(x => x.id.toLowerCase() === id.trim().toLowerCase() && x.pass === pass);
      if (!u) return null; const o = { role, id: u.id }; sessionStorage.setItem('kok_user', JSON.stringify(o)); return o;
    },
    logout() { sessionStorage.removeItem('kok_user'); location.href = 'portal.html'; },
    who(u) { u = u || api.user(); if (!u) return null; const pool = { student: db.students, parent: db.parents, teacher: db.teachers, admin: db.staff }[u.role]; return pool.find(x => x.id === u.id); },
    student: id => db.students.find(s => s.id === id),
    kids: pid => db.students.filter(s => s.par === pid),
    score(sid, sub) { return db.scores[sid + '|' + sub] || { mid: null, exam: null }; },
    results(sid) {
      const s = api.student(sid);
      return subjectsFor(s.cls).map(sub => { const sc = api.score(sid, sub); const t = (sc.mid ?? 0) + (sc.exam ?? 0); return { sub, mid: sc.mid, exam: sc.exam, total: t, g: grade(t) }; });
    },
    invoice(sid) {
      const s = api.student(sid);
      return feeItems(s.cls).map(([item, due]) => {
        const paid = db.payments.filter(p => p.sid === sid).reduce((a, p) => a + p.items.filter(i => i[0] === item).reduce((x, i) => x + i[1], 0), 0);
        return { item, due, paid, bal: Math.max(0, due - paid) };
      });
    },
    owed: sid => api.invoice(sid).reduce((a, i) => a + i.bal, 0),
    billed: sid => api.invoice(sid).reduce((a, i) => a + i.due, 0),
    makePayment(sid, par, items, method) {
      const total = items.reduce((a, b) => a + b[1], 0);
      const p = { id: 'RCP-' + (++db.nextId), sid, par, items, total, method, date: new Date().toISOString().slice(0, 10), status: 'Confirmed' };
      db.payments.unshift(p); save(db); return p;
    },
    position(sid) {
      const s = api.student(sid); const mates = db.students.filter(x => x.cls === s.cls);
      const tot = x => api.results(x.id).reduce((a, r) => a + r.total, 0);
      const sorted = mates.map(m => [m.id, tot(m)]).sort((a, b) => b[1] - a[1]);
      return [sorted.findIndex(x => x[0] === sid) + 1, mates.length];
    }
  };
  return api;
})();

const ord = n => n + (['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) ? 0 : (n % 10 < 4 ? n % 10 : 0)]);
const fdate = d => new Date(d + 'T00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
document.addEventListener('DOMContentLoaded', mountSite);

/* install as app (PWA) */
const KOK_APP = {
  ios: /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream,
  standalone: window.matchMedia('(display-mode: standalone)').matches || navigator.standalone,
  can: () => !!window.__ip,
  async install() { if (!window.__ip) return false; window.__ip.prompt(); const r = await window.__ip.userChoice; window.__ip = null; return r.outcome === 'accepted'; }
};
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); window.__ip = e; document.dispatchEvent(new Event('kok-installable')); });
window.addEventListener('appinstalled', () => { window.__ip = null; toast('App installed. Find it on your home screen.'); });
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => { }));
