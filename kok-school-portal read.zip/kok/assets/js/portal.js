/* King of Kings portal: student, parent, teacher and leadership dashboards */
const Portal = (() => {
  const db = () => KOK.db;
  const initials = n => n.replace(/^(Mr and Mrs|Mrs|Mr|Miss|Alhaji|Chairman,)\s+/i, '').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const gb = g => `<span class="grade g-${g}">${g}</span>`;
  const kpi = (l, v, ic, c = '') => `<div class="kpi ${c}"><div class="ic">${ic}</div><small>${l}</small><b>${v}</b></div>`;
  const feeState = sid => { const o = KOK.owed(sid), b = KOK.billed(sid); return o === 0 ? ['Paid', 'ok'] : o === b ? ['Unpaid', 'bad'] : ['Part paid', 'warn']; };
  const st = ([t, c]) => `<span class="st ${c}">${t}</span>`;
  const pub = (sec, k) => db().published[sec][k];
  const avg = a => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : 0;
  const annFor = (role, sec) => db().announcements.filter(a => a.to === 'all' || a.to === sec || (a.to === 'parents' && role === 'parent')).sort((a, b) => b.d.localeCompare(a.d));
  const annHtml = list => `<div class="ann">${list.map((a, i) => `<div class="${i % 2 ? 'pk' : ''}"><b>${a.t}</b><small>${fdate(a.d)}</small><p style="font-size:.85rem;margin-top:4px">${a.b}</p></div>`).join('') || '<div class="empty">No notices yet</div>'}</div>`;
  const openModal = html => { $('#mbox').innerHTML = html; $('#modal').classList.add('on'); };
  const closeModal = () => $('#modal').classList.remove('on');

  function receipt(p) {
    const s = KOK.student(p.sid);
    return `<div class="receipt"><div class="tick">✓</div><h3 style="text-align:center;font-size:1.5rem">Payment successful</h3>
      <p style="text-align:center;margin-bottom:16px">Receipt <b>${p.id}</b> · ${fdate(p.date)}</p>
      <table><tbody><tr><td>Student</td><td style="text-align:right"><b>${s.name}</b><br><small>${s.id} · ${s.cls}</small></td></tr>
      ${p.items.map(i => `<tr><td>${i[0]}</td><td style="text-align:right">${naira(i[1])}</td></tr>`).join('')}
      <tr><td><b>Total paid</b></td><td style="text-align:right"><b style="font-size:1.2rem;color:var(--g700)">${naira(p.total)}</b></td></tr>
      <tr><td>Method</td><td style="text-align:right">${p.method}</td></tr><tr><td>Session</td><td style="text-align:right">${db().session}, ${db().term}</td></tr>
      <tr><td>Status</td><td style="text-align:right">${st(['Confirmed', 'ok'])}</td></tr></tbody></table>
      <p style="margin-top:12px;font-size:.78rem;text-align:center">King of Kings International School · Recorded on the school ledger</p></div>
      <div class="cta-row no-print" style="margin-top:18px"><button class="btn btn-primary" onclick="window.print()">🖨️ Print receipt</button><button class="btn btn-ghost" id="mc">Close</button></div>`;
  }
  const showReceipt = id => { const p = db().payments.find(x => x.id === id); openModal(receipt(p)); $('#mc').onclick = closeModal; };

  /* shared result view */
  function resultsView(sid) {
    const s = KOK.student(sid), r = KOK.results(sid), P = pub(s.sec, 'mid'), E = pub(s.sec, 'exam');
    const show = E ? r.map(x => x.total) : [];
    const a = avg(r.map(x => x.total)), [pos, of] = KOK.position(sid);
    const head = `<div class="dgrid k4" style="margin-bottom:18px">
      ${kpi('Average score', E ? a + '%' : '—', '📈', 'gr')}${kpi('Class position', E ? ord(pos) + ' of ' + of : '—', '🏅', 'pk')}
      ${kpi('Best subject', E ? r.slice().sort((x, y) => y.total - x.total)[0].sub.split(' ').slice(0, 2).join(' ') : '—', '⭐')}${kpi('Subjects', r.length, '📚', 'pk')}</div>`;
    const rows = r.map(x => `<tr><td><b>${KOK.icon(x.sub)} ${x.sub}</b></td>
      <td>${P ? x.mid + ' / 30' : '<span class="st neu">Pending</span>'}</td><td>${E ? x.exam + ' / 70' : '<span class="st neu">Pending</span>'}</td>
      <td><b>${E ? x.total : '—'}</b></td><td>${E ? gb(x.g[0]) : ''}</td><td>${E ? x.g[1] : ''}</td>
      <td style="min-width:120px">${E ? `<div class="bar ${x.total < 50 ? 'p' : ''}"><i style="width:${x.total}%"></i></div>` : ''}</td></tr>`).join('');
    return `${head}<div class="panel"><h3>${s.name} · ${s.cls} <span class="lnk no-print" onclick="window.print()">🖨️ Print report card</span></h3>
      ${!E ? '<p style="margin-bottom:12px">Exam scores will appear here once the school publishes them.</p>' : ''}
      <div class="tw"><table><thead><tr><th>Subject</th><th>Mid Term</th><th>Exam</th><th>Total</th><th>Grade</th><th>Remark</th><th>Performance</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p style="margin-top:14px;font-size:.78rem">Grading: A 75 to 100 · B 65 to 74 · C 50 to 64 · D 45 to 49 · E 40 to 44 · F below 40. ${db().session}, ${db().term}.</p></div>`;
  }
  function invoiceTable(sid) {
    const inv = KOK.invoice(sid);
    return `<div class="tw"><table><thead><tr><th>Item</th><th>Amount due</th><th>Paid</th><th>Balance</th></tr></thead><tbody>
      ${inv.map(i => `<tr><td><b>${i.item}</b></td><td>${naira(i.due)}</td><td>${naira(i.paid)}</td><td>${i.bal ? `<b style="color:#b22c58">${naira(i.bal)}</b>` : st(['Cleared', 'ok'])}</td></tr>`).join('')}
      <tr><td><b>Total</b></td><td><b>${naira(KOK.billed(sid))}</b></td><td><b>${naira(KOK.billed(sid) - KOK.owed(sid))}</b></td><td><b>${naira(KOK.owed(sid))}</b></td></tr></tbody></table></div>`;
  }
  function historyTable(list, showStu = true) {
    if (!list.length) return '<div class="empty"><b>🧾</b>No payments recorded yet</div>';
    return `<div class="tw"><table><thead><tr><th>Receipt</th><th>Date</th>${showStu ? '<th>Student</th>' : ''}<th>Items</th><th>Amount</th><th>Method</th><th></th></tr></thead><tbody>
      ${list.map(p => `<tr><td><b>${p.id}</b></td><td>${fdate(p.date)}</td>${showStu ? `<td>${KOK.student(p.sid).name}<br><small>${p.sid}</small></td>` : ''}<td>${p.items.map(i => i[0]).join(', ')}</td><td><b>${naira(p.total)}</b></td><td>${p.method}</td>
      <td><button class="btn btn-soft btn-sm" data-rc="${p.id}">Receipt</button></td></tr>`).join('')}</tbody></table></div>`;
  }
  const bindReceipts = el => $$('[data-rc]', el).forEach(b => b.onclick = () => showReceipt(b.dataset.rc));

  function timetable(cls) {
    const subs = KOK.subjectsFor(cls); const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const times = ['8:00', '8:45', '9:30', '10:15', '11:00', '11:45', '12:30'];
    let h = '<div class="tt"><div class="h">Time</div>' + days.map(d => `<div class="h">${d}</div>`).join('');
    times.forEach((t, p) => {
      h += `<div class="h">${t}</div>`;
      days.forEach((d, di) => { h += p === 3 ? '<div class="brk">Short break 🍎</div>' : p === 5 && di === 4 ? '<div class="brk">Club / Etiquette</div>' : `<div class="t">${subs[(p * 3 + di * 2 + (p > 3 ? -1 : 0)) % subs.length]}</div>`; });
    });
    return h + '</div>';
  }

  /* ========== STUDENT ========== */
  const student = {
    title: 'Student Portal', nav: [['overview', '🏠', 'Overview'], ['results', '📊', 'Results'], ['fees', '💳', 'School Fees'], ['subjects', '📚', 'My Subjects'], ['timetable', '🗓️', 'Timetable'], ['notices', '📣', 'Notices']],
    views: {
      overview(me) {
        const r = KOK.results(me.id), E = pub(me.sec, 'exam'), [pos, of] = KOK.position(me.id);
        return {
          title: `Hello, ${me.name.split(' ')[0]} 👋`, sub: `${me.cls} · ${me.id} · ${db().session} ${db().term}`,
          html: `<div class="dgrid k4">${kpi('Attendance', me.attendance + '%', '✅')}${kpi('Average score', E ? avg(r.map(x => x.total)) + '%' : '—', '📈', 'gr')}${kpi('Class position', E ? ord(pos) + ' of ' + of : '—', '🏅', 'pk')}${kpi('Fee balance', naira(KOK.owed(me.id)), '💳', KOK.owed(me.id) ? 'pk' : '')}</div>
          <div class="dgrid k2" style="margin-top:18px"><div class="panel"><h3>This term's performance <a href="#results">See all →</a></h3>
            ${E ? r.slice(0, 7).map(x => `<div style="display:grid;grid-template-columns:150px 1fr 40px;gap:12px;align-items:center;margin-bottom:12px;font-size:.85rem"><span>${x.sub}</span><div class="bar ${x.total < 50 ? 'p' : ''}"><i style="width:${x.total}%"></i></div><b>${x.total}</b></div>`).join('') : '<div class="empty"><b>⏳</b>Results not published yet</div>'}</div>
          <div class="panel"><h3>Notices <a href="#notices">All</a></h3>${annHtml(annFor('student', me.sec).slice(0, 3))}</div></div>`
        };
      },
      subjects(me) { const s = KOK.subjectsFor(me.cls); return { title: 'My Subjects', sub: `${s.length} subjects registered for ${db().term}, ${me.cls}`, html: `<div class="panel"><div class="subj">${s.map(x => `<div><i>${KOK.icon(x)}</i>${x}</div>`).join('')}</div></div>` }; },
      timetable(me) { return { title: 'Class Timetable', sub: me.cls, html: `<div class="panel tw">${timetable(me.cls)}</div>` }; },
      results(me) { return { title: 'My Results', sub: 'Mid term and examination scores', html: resultsView(me.id) }; },
      fees(me) { return { title: 'School Fees', sub: `${db().session}, ${db().term}`, html: `<div class="panel"><h3>Fee invoice ${st(feeState(me.id))}</h3>${invoiceTable(me.id)}<p style="margin-top:14px">Payments are made by your parent or guardian from the Parent Portal.</p></div>` }; },
      notices(me) { return { title: 'Notices', sub: 'From your teachers and school leaders', html: `<div class="panel">${annHtml(annFor('student', me.sec))}</div>` }; }
    }
  };

  /* ========== PARENT ========== */
  const kidKey = 'kok_kid';
  const curKid = me => { const k = KOK.kids(me.id); const id = sessionStorage.getItem(kidKey); return k.find(x => x.id === id) || k[0]; };
  const kidBar = (me, rerender) => `<div class="sw" style="margin-bottom:20px">${KOK.kids(me.id).map(k => `<div class="child ${k.id === curKid(me).id ? 'on' : ''}" data-kid="${k.id}"><div class="av" style="width:36px;height:36px;font-size:.85rem">${initials(k.name)}</div><div>${k.name}<small>${k.cls} · ${k.sec === 'primary' ? 'Primary' : 'College'}</small></div></div>`).join('')}</div>`;
  const parent = {
    title: 'Parent Portal', nav: [['overview', '🏠', 'Overview'], ['pay', '💳', 'Pay School Fees'], ['results', '📊', 'Results'], ['history', '🧾', 'Payment History'], ['notices', '📣', 'Notices']],
    views: {
      overview(me) {
        const kids = KOK.kids(me.id), owed = kids.reduce((a, k) => a + KOK.owed(k.id), 0);
        return {
          title: `Welcome, ${me.name}`, sub: `${kids.length} child${kids.length > 1 ? 'ren' : ''} enrolled · ${db().session} ${db().term}`,
          html: `<div class="dgrid k3">${kpi('Total outstanding', naira(owed), '💳', owed ? 'pk' : 'gr')}${kpi('Children enrolled', kids.length, '👧🏽')}${kpi('Payments made', db().payments.filter(p => p.par === me.id).length, '🧾')}</div>
          <div class="dgrid k2" style="margin-top:18px"><div class="panel"><h3>My children</h3>
          ${kids.map(k => { const r = KOK.results(k.id), [p, o] = KOK.position(k.id), E = pub(k.sec, 'exam'); return `<div style="display:flex;gap:16px;align-items:center;padding:14px 0;border-bottom:1px solid var(--line);flex-wrap:wrap"><div class="av" style="width:52px;height:52px">${initials(k.name)}</div>
            <div style="flex:1;min-width:180px"><b>${k.name}</b><br><small style="color:var(--mut)">${k.cls} · ${k.id} · ${k.sec === 'primary' ? 'Primary School' : 'College'}</small></div>
            <div style="text-align:center"><small>Average</small><br><b>${E ? avg(r.map(x => x.total)) + '%' : '—'}</b></div><div style="text-align:center"><small>Position</small><br><b>${E ? ord(p) + '/' + o : '—'}</b></div>
            <div style="text-align:center"><small>Balance</small><br><b>${naira(KOK.owed(k.id))}</b></div><div>${st(feeState(k.id))}</div>
            <button class="btn btn-primary btn-sm" data-go="pay" data-k="${k.id}">${KOK.owed(k.id) ? 'Pay fees' : 'View'}</button></div>`; }).join('')}</div>
          <div class="panel"><h3>Notices <a href="#notices">All</a></h3>${annHtml(annFor('parent', kids[0].sec).slice(0, 3))}</div></div>`,
          bind(el) { $$('[data-go]', el).forEach(b => b.onclick = () => { sessionStorage.setItem(kidKey, b.dataset.k); location.hash = b.dataset.go; }); }
        };
      },
      pay(me, rerender) {
        const k = curKid(me), inv = KOK.invoice(k.id);
        return {
          title: 'Pay School Fees', sub: 'Pay in full or part pay each item. Receipts are recorded instantly.',
          html: `${kidBar(me)}<div class="dgrid k2"><div class="panel"><h3>${k.name}'s invoice ${st(feeState(k.id))}</h3>
          <div class="paylist">${inv.map((i, n) => `<label class="payline ${i.bal ? '' : 'done'}"><input type="checkbox" data-n="${n}" ${i.bal ? 'checked' : 'disabled'}>
          <span class="pi"><b>${i.item}</b><small>Due ${naira(i.due)} · Paid ${naira(i.paid)}</small></span>
          ${i.bal ? `<span class="pa"><small>Balance ${naira(i.bal)}</small><input class="inp-s" type="number" inputmode="numeric" min="0" max="${i.bal}" value="${i.bal}" data-a="${n}" aria-label="Amount to pay for ${i.item}"></span>` : st(['Cleared', 'ok'])}</label>`).join('')}</div></div>
          <div class="panel"><h3>Payment summary</h3><p>Selected items</p><b id="tot" style="font-family:var(--head);font-size:2.4rem;color:var(--g700)">${naira(0)}</b>
          <p style="margin:14px 0 20px;font-size:.85rem">Secure payment by card, bank transfer or USSD. A receipt is issued immediately and saved on the school ledger.</p>
          <button class="btn btn-primary btn-block" id="pb">Pay now →</button>
          <p style="font-size:.74rem;margin-top:12px">Prototype note: no real money moves. In production this connects to a live payment gateway such as Paystack or Flutterwave.</p></div></div>`,
          bind(el) {
            $$('[data-kid]', el).forEach(c => c.onclick = () => { sessionStorage.setItem(kidKey, c.dataset.kid); rerender(); });
            const lines = () => inv.map((i, n) => { const c = $(`[data-n="${n}"]`, el), a = $(`[data-a="${n}"]`, el); if (!a) return null; const v = Math.min(i.bal, Math.max(0, Math.round(+a.value || 0))); return c.checked && v > 0 ? [i.item, v] : null; }).filter(Boolean);
            const upd = () => { $('#tot', el).textContent = naira(lines().reduce((a, b) => a + b[1], 0)); };
            $$('input', el).forEach(i => i.oninput = i.onchange = upd); upd();
            $('#pb', el).onclick = () => { const L = lines(); if (!L.length) return toast('Select at least one item to pay'); checkout(k, me, L, rerender); };
          }
        };
      },
      results(me, rerender) { const k = curKid(me); return { title: 'Results', sub: 'Mid term and examination results', html: kidBar(me) + resultsView(k.id), bind(el) { $$('[data-kid]', el).forEach(c => c.onclick = () => { sessionStorage.setItem(kidKey, c.dataset.kid); rerender(); }); } }; },
      history(me) { const l = db().payments.filter(p => p.par === me.id); return { title: 'Payment History', sub: 'Every payment recorded against your children', html: `<div class="panel">${historyTable(l)}</div>`, bind: bindReceipts }; },
      notices(me) { return { title: 'Notices', sub: 'Messages from the school', html: `<div class="panel">${annHtml(annFor('parent', KOK.kids(me.id)[0].sec))}</div>` }; }
    }
  };

  function checkout(k, me, L, rerender) {
    const total = L.reduce((a, b) => a + b[1], 0); let method = 'Card';
    const body = () => `<h3 style="font-size:1.5rem">Complete payment</h3><p>${k.name} · <b style="color:var(--g700)">${naira(total)}</b></p>
      <div class="paym">${['Card', 'Bank Transfer', 'USSD'].map(m => `<button data-m="${m}" class="${m === method ? 'on' : ''}">${{ Card: '💳', 'Bank Transfer': '🏦', USSD: '📱' }[m]} ${m}</button>`).join('')}</div>
      <div id="mm">${method === 'Card' ? `<div class="field"><label>Card number (demo)</label><input placeholder="4242 4242 4242 4242" maxlength="19"></div><div class="row2"><div class="field"><label>Expiry</label><input placeholder="12/29"></div><div class="field"><label>CVV</label><input placeholder="123" maxlength="3"></div></div>`
        : method === 'Bank Transfer' ? `<div class="demo" style="margin:0 0 14px">Transfer <b>${naira(total)}</b> to<br><b>King of Kings International School</b><br>Demo Bank · 0123456789<br>Reference: <b>${k.id}</b></div>` : `<div class="demo" style="margin:0 0 14px">Dial <b>*737*000*${total}#</b> on your phone and follow the prompts. (Demo code)</div>`}</div>
      <div class="cta-row"><button class="btn btn-primary" id="go">${method === 'Bank Transfer' ? 'I have transferred' : method === 'USSD' ? 'I have paid' : 'Pay ' + naira(total)}</button><button class="btn btn-ghost" id="cx">Cancel</button></div>`;
    const draw = () => { openModal(body()); $$('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; draw(); }); $('#cx').onclick = closeModal; $('#go').onclick = go; };
    const go = () => { $('#mbox').innerHTML = '<div class="spin"></div><p style="text-align:center">Confirming your payment…</p>'; setTimeout(() => { const p = KOK.makePayment(k.id, me.id, L, method); $('#mbox').innerHTML = receipt(p); $('#mc').onclick = () => { closeModal(); rerender(); }; }, 1500); };
    draw();
  }

  /* ========== TEACHER ========== */
  const tKey = 'kok_asg';
  const curAsg = me => Math.min(+sessionStorage.getItem(tKey) || 0, me.load.length - 1);
  const classStudents = cls => db().students.filter(s => s.cls === cls);
  const teacher = {
    title: 'Teacher Portal', nav: [['overview', '🏠', 'Overview'], ['scores', '✍🏽', 'Score Entry'], ['classes', '🏫', 'My Classes'], ['notices', '📣', 'Notices']],
    views: {
      overview(me) {
        const n = me.load.reduce((a, [c]) => a + classStudents(c).length, 0);
        return {
          title: `Good day, ${me.name}`, sub: `${me.title} · ${me.sec === 'primary' ? 'Primary School' : 'College'}`,
          html: `<div class="dgrid k3">${kpi('Class and subject loads', me.load.length, '📚', 'gr')}${kpi('Students taught', n, '🧑🏽‍🎓')}${kpi('Score sheets complete', '100%', '✅', 'pk')}</div>
          <div class="panel" style="margin-top:18px"><h3>My teaching load</h3><div class="subj">${me.load.map(([c, s], i) => `<div style="cursor:pointer" data-a="${i}"><i>${KOK.icon(s)}</i><span>${s}<br><small style="color:var(--mut)">${c} · ${classStudents(c).length} students</small></span></div>`).join('')}</div></div>
          <div class="panel" style="margin-top:18px"><h3>Notices</h3>${annHtml(annFor('teacher', me.sec).slice(0, 3))}</div>`,
          bind(el) { $$('[data-a]', el).forEach(b => b.onclick = () => { sessionStorage.setItem(tKey, b.dataset.a); location.hash = 'scores'; }); }
        };
      },
      scores(me) {
        const ai = curAsg(me), [cls, sub] = me.load[ai], list = classStudents(cls);
        return {
          title: 'Score Entry', sub: 'Enter mid term (30) and exam (70) scores. Totals and grades are automatic.',
          html: `<div class="sw" style="margin-bottom:18px"><select id="asg">${me.load.map(([c, s], i) => `<option value="${i}" ${i === ai ? 'selected' : ''}>${c} · ${s}</option>`).join('')}</select>
            ${st(pub(list[0]?.sec || me.sec, 'exam') ? ['Results published', 'ok'] : ['Draft', 'warn'])}</div>
          <div class="panel"><h3>${sub} · ${cls} <span class="lnk" id="sv">💾 Save scores</span></h3>
          ${list.length ? `<div class="tw"><table><thead><tr><th>Reg No.</th><th>Student</th><th>Mid Term /30</th><th>Exam /70</th><th>Total</th><th>Grade</th></tr></thead><tbody>
          ${list.map(s => { const sc = KOK.score(s.id, sub); return `<tr data-s="${s.id}"><td>${s.id}</td><td><b>${s.name}</b></td><td><input class="inp-s" type="number" min="0" max="30" value="${sc.mid ?? ''}" data-k="mid"></td><td><input class="inp-s" type="number" min="0" max="70" value="${sc.exam ?? ''}" data-k="exam"></td><td class="tot"></td><td class="gr"></td></tr>`; }).join('')}</tbody></table></div>
          <div class="cta-row" style="margin-top:18px"><button class="btn btn-primary" id="sv2">Save scores</button></div>` : '<div class="empty"><b>🪑</b>No students are registered in this class yet.</div>'}</div>`,
          bind(el) {
            $('#asg', el).onchange = e => { sessionStorage.setItem(tKey, e.target.value); location.hash = 'scores'; window.dispatchEvent(new HashChangeEvent('hashchange')); };
            const calc = tr => { const m = +$('[data-k=mid]', tr).value || 0, x = +$('[data-k=exam]', tr).value || 0, t = m + x, g = KOK.grade(t)[0]; $('.tot', tr).innerHTML = `<b>${t}</b>`; $('.gr', tr).innerHTML = gb(g); };
            $$('tbody tr', el).forEach(tr => { calc(tr); $$('input', tr).forEach(i => i.oninput = () => { i.value = Math.min(+i.max, Math.max(0, i.value === '' ? '' : Math.round(i.value))); calc(tr); }); });
            const save = () => { $$('tbody tr', el).forEach(tr => { db().scores[tr.dataset.s + '|' + sub] = { mid: +$('[data-k=mid]', tr).value || 0, exam: +$('[data-k=exam]', tr).value || 0 }; }); KOK.save(); toast('Scores saved. Leadership can now publish them.'); };
            $('#sv', el) && ($('#sv', el).onclick = save); $('#sv2', el) && ($('#sv2', el).onclick = save);
          }
        };
      },
      classes(me) {
        const cs = [...new Set(me.load.map(l => l[0]))];
        return { title: 'My Classes', sub: 'Students in the classes you teach', html: cs.map(c => `<div class="panel" style="margin-bottom:18px"><h3>${c} <span class="st neu">${classStudents(c).length} students</span></h3>${classStudents(c).length ? `<div class="tw"><table><thead><tr><th>Reg No.</th><th>Name</th><th>Attendance</th></tr></thead><tbody>${classStudents(c).map(s => `<tr><td>${s.id}</td><td><b>${s.name}</b></td><td>${s.attendance}%</td></tr>`).join('')}</tbody></table></div>` : '<p>No students registered yet.</p>'}</div>`).join('') };
      },
      notices(me) { return { title: 'Notices', sub: 'From school leadership', html: `<div class="panel">${annHtml(annFor('teacher', me.sec))}</div>` }; }
    }
  };

  /* ========== LEADERSHIP ========== */
  const SC = 'kok_scope';
  const scopeOf = me => me.scope === 'all' ? (sessionStorage.getItem(SC) || 'all') : me.scope;
  const inScope = (me, list, key = 'sec') => { const s = scopeOf(me); return s === 'all' ? list : list.filter(x => x[key] === s); };
  const scopeBar = me => me.scope === 'all' ? `<div class="tabs" style="margin:0 0 18px">${[['all', 'Whole school'], ['primary', 'Primary'], ['college', 'College']].map(([k, t]) => `<button data-sc="${k}" class="${scopeOf(me) === k ? 'on' : ''}">${t}</button>`).join('')}</div>` : '';
  const bindScope = (el, rr) => $$('[data-sc]', el).forEach(b => b.onclick = () => { sessionStorage.setItem(SC, b.dataset.sc); rr(); });
  const sumPaid = sids => db().payments.filter(p => sids.includes(p.sid)).reduce((a, p) => a + p.total, 0);
  const csv = (name, rows) => { const b = new Blob([rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n')], { type: 'text/csv' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; a.click(); };
  const admin = {
    title: 'Leadership Portal', nav: [['overview', '🏠', 'Overview'], ['students', '🧑🏽‍🎓', 'Students'], ['fees', '💳', 'Fees and Payments'], ['results', '📊', 'Results Control'], ['applications', '📝', 'Applications'], ['notices', '📣', 'Announcements'], ['staff', '👥', 'Staff']],
    views: {
      overview(me, rr) {
        const S = inScope(me, db().students), ids = S.map(s => s.id), billed = S.reduce((a, s) => a + KOK.billed(s.id), 0), paid = sumPaid(ids), owed = billed - paid;
        const byCls = [...new Set(S.map(s => s.cls))].map(c => { const m = S.filter(s => s.cls === c), b = m.reduce((a, s) => a + KOK.billed(s.id), 0), p = sumPaid(m.map(s => s.id)); return [c, b ? Math.round(p / b * 100) : 0, m.length]; });
        return {
          title: me.role === 'Proprietor' ? 'School Overview' : `${me.role}'s Dashboard`, sub: `${me.name} · ${db().session} ${db().term}`,
          html: `${scopeBar(me)}<div class="dgrid k4">${kpi('Students enrolled', S.length, '🧑🏽‍🎓', 'gr')}${kpi('Fees collected', naira(paid), '💰')}${kpi('Outstanding', naira(owed), '⏳', 'pk')}${kpi('Collection rate', billed ? Math.round(paid / billed * 100) + '%' : '0%', '📈')}</div>
          <div class="dgrid k2" style="margin-top:18px"><div class="panel"><h3>Fee collection by class</h3>${byCls.map(([c, p, n]) => `<div style="display:grid;grid-template-columns:110px 1fr 46px;gap:12px;align-items:center;margin-bottom:12px;font-size:.85rem"><span>${c} <small style="color:var(--mut)">(${n})</small></span><div class="bar ${p < 60 ? 'p' : ''}"><i style="width:${p}%"></i></div><b>${p}%</b></div>`).join('')}</div>
          <div class="panel"><h3>Applications <a href="#applications">Open</a></h3><div style="font-family:var(--head);font-size:2.6rem;font-weight:800;color:var(--g700)">${db().applications.length}</div><p>new admission applications received through the website.</p>
          <h3 style="margin-top:22px">Latest notice</h3>${annHtml(annFor('admin', 'all').slice(0, 1))}</div></div>
          <div class="panel" style="margin-top:18px"><h3>Recent payments <a href="#fees">View ledger</a></h3>${historyTable(db().payments.filter(p => ids.includes(p.sid)).slice(0, 5))}</div>`,
          bind(el) { bindScope(el, rr); bindReceipts(el); }
        };
      },
      students(me, rr) {
        return {
          title: 'Students', sub: 'Everyone enrolled in your scope',
          html: `${scopeBar(me)}<div class="sw" style="margin-bottom:16px"><input id="q" placeholder="Search name or ID"><select id="fc"><option value="">All classes</option>${[...new Set(inScope(me, db().students).map(s => s.cls))].map(c => `<option>${c}</option>`).join('')}</select><select id="ff"><option value="">All fee status</option><option>Paid</option><option>Part paid</option><option>Unpaid</option></select></div>
          <div class="panel"><div class="tw"><table><thead><tr><th>Reg No.</th><th>Name</th><th>Class</th><th>Attendance</th><th>Fee status</th><th>Balance</th><th></th></tr></thead><tbody id="tb"></tbody></table></div></div>`,
          bind(el) {
            bindScope(el, rr);
            const draw = () => { const q = $('#q', el).value.toLowerCase(), c = $('#fc', el).value, f = $('#ff', el).value;
              const L = inScope(me, db().students).filter(s => (!q || (s.name + s.id).toLowerCase().includes(q)) && (!c || s.cls === c) && (!f || feeState(s.id)[0] === f));
              $('#tb', el).innerHTML = L.map(s => `<tr><td>${s.id}</td><td><b>${s.name}</b></td><td>${s.cls}</td><td>${s.attendance}%</td><td>${st(feeState(s.id))}</td><td>${naira(KOK.owed(s.id))}</td><td><button class="btn btn-soft btn-sm" data-v="${s.id}">View</button></td></tr>`).join('') || '<tr><td colspan="7"><div class="empty">No students match</div></td></tr>';
              $$('[data-v]', el).forEach(b => b.onclick = () => { const s = KOK.student(b.dataset.v), par = db().parents.find(p => p.id === s.par);
                openModal(`<h3 style="font-size:1.5rem">${s.name}</h3><p>${s.id} · ${s.cls} · Parent: ${par.name} (${par.phone})</p><h3 style="margin:18px 0 8px;font-size:1rem">Fee invoice</h3>${invoiceTable(s.id)}<button class="btn btn-ghost" id="mc" style="margin-top:18px">Close</button>`); $('#mc').onclick = closeModal; }); };
            $$('#q,#fc,#ff', el).forEach(i => i.oninput = i.onchange = draw); draw();
          }
        };
      },
      fees(me, rr) {
        const S = inScope(me, db().students), ids = S.map(s => s.id), P = db().payments.filter(p => ids.includes(p.sid));
        const debtors = S.filter(s => KOK.owed(s.id)).sort((a, b) => KOK.owed(b.id) - KOK.owed(a.id));
        return {
          title: 'Fees and Payments', sub: 'Every payment parents make is recorded here instantly',
          html: `${scopeBar(me)}<div class="dgrid k3">${kpi('Collected', naira(sumPaid(ids)), '💰', 'gr')}${kpi('Outstanding', naira(S.reduce((a, s) => a + KOK.owed(s.id), 0)), '⏳', 'pk')}${kpi('Payments', P.length, '🧾')}</div>
          <div class="panel" style="margin-top:18px"><h3>Payment ledger <span class="lnk" id="ex">⬇ Export CSV</span></h3>${historyTable(P)}</div>
          <div class="panel" style="margin-top:18px"><h3>Outstanding balances</h3><div class="tw"><table><thead><tr><th>Student</th><th>Class</th><th>Parent</th><th>Phone</th><th>Balance</th></tr></thead><tbody>
          ${debtors.map(s => { const p = db().parents.find(x => x.id === s.par); return `<tr><td><b>${s.name}</b></td><td>${s.cls}</td><td>${p.name}</td><td>${p.phone}</td><td><b style="color:#b22c58">${naira(KOK.owed(s.id))}</b></td></tr>`; }).join('') || '<tr><td colspan="5"><div class="empty">Everyone is cleared 🎉</div></td></tr>'}</tbody></table></div></div>`,
          bind(el) { bindScope(el, rr); bindReceipts(el); $('#ex', el).onclick = () => csv('kok-payments.csv', [['Receipt', 'Date', 'Student ID', 'Student', 'Items', 'Amount', 'Method']].concat(P.map(p => [p.id, p.date, p.sid, KOK.student(p.sid).name, p.items.map(i => i[0]).join('; '), p.total, p.method]))); }
        };
      },
      results(me, rr) {
        const secs = me.scope === 'all' ? ['primary', 'college'] : [me.scope];
        return {
          title: 'Results Control', sub: 'Teachers enter scores. You decide when parents and students can see them.',
          html: `${secs.map(sc => `<div class="panel" style="margin-bottom:18px"><h3>${sc === 'primary' ? '🧸 Primary School' : '🎓 College'}</h3>
          <div class="dgrid k2" style="grid-template-columns:1fr 1fr">${[['mid', 'Mid Term results'], ['exam', 'Examination results']].map(([k, t]) => `<div class="kpi"><small>${t}</small><b style="font-size:1.3rem">${pub(sc, k) ? 'Published' : 'Hidden'}</b><button class="btn ${pub(sc, k) ? 'btn-ghost' : 'btn-primary'} btn-sm" data-p="${sc}|${k}" style="margin-top:12px">${pub(sc, k) ? 'Unpublish' : 'Publish to portal'}</button></div>`).join('')}</div>
          <h3 style="margin:22px 0 10px;font-size:1rem">Class averages (total score)</h3><div class="tw"><table><thead><tr><th>Class</th><th>Students</th><th>Average</th></tr></thead><tbody>
          ${KOK.classes[sc].map(c => { const m = db().students.filter(s => s.cls === c); if (!m.length) return ''; const a = avg(m.map(s => avg(KOK.results(s.id).map(r => r.total)))); return `<tr><td><b>${c}</b></td><td>${m.length}</td><td style="min-width:200px"><div style="display:flex;gap:10px;align-items:center"><div class="bar" style="flex:1"><i style="width:${a}%"></i></div><b>${a}%</b></div></td></tr>`; }).join('')}</tbody></table></div></div>`).join('')}`,
          bind(el) { $$('[data-p]', el).forEach(b => b.onclick = () => { const [sc, k] = b.dataset.p.split('|'); db().published[sc][k] = !db().published[sc][k]; KOK.save(); toast(db().published[sc][k] ? 'Results are now visible to parents and students' : 'Results hidden'); rr(); }); }
        };
      },
      applications(me, rr) {
        const A = db().applications;
        return {
          title: 'Admission Applications', sub: 'Submitted from the Admissions page of the website',
          html: `<div class="panel">${A.length ? `<div class="tw"><table><thead><tr><th>Ref</th><th>Child</th><th>Class</th><th>Parent</th><th>Phone</th><th>Date</th><th>Status</th></tr></thead><tbody>
          ${A.map((a, i) => `<tr><td>${a.id}</td><td><b>${a.child}</b></td><td>${a.cls}</td><td>${a.par}</td><td>${a.phone}</td><td>${fdate(a.date)}</td><td><select data-i="${i}" style="width:auto;padding:6px 10px">${['New', 'Invited for tour', 'Assessment booked', 'Admitted', 'Declined'].map(s => `<option ${s === a.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty"><b>📝</b>No applications yet. Submit one from the Admissions page on the website and it will appear here.<br><br><a class="btn btn-soft" href="admissions.html">Open Admissions page</a></div>'}</div>`,
          bind(el) { $$('[data-i]', el).forEach(s => s.onchange = () => { A[s.dataset.i].status = s.value; KOK.save(); toast('Status updated'); }); }
        };
      },
      notices(me, rr) {
        return {
          title: 'Announcements', sub: 'Post a notice to parents, students and staff',
          html: `<div class="dgrid k2" style="grid-template-columns:1fr 1.3fr"><form class="panel" id="nf"><h3>New announcement</h3><div class="field"><label>Title</label><input name="t" required></div><div class="field"><label>Message</label><textarea name="b" rows="4" required></textarea></div>
          <div class="field"><label>Audience</label><select name="to"><option value="all">Everyone</option><option value="primary">Primary School</option><option value="college">College</option><option value="parents">Parents only</option></select></div><button class="btn btn-primary btn-block">Publish notice</button></form>
          <div class="panel"><h3>Published notices</h3>${annHtml(db().announcements.slice().sort((a, b) => b.d.localeCompare(a.d)))}</div></div>`,
          bind(el) { $('#nf', el).onsubmit = e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); db().announcements.unshift({ id: ++db().nextId, t: f.t, b: f.b, to: f.to, d: new Date().toISOString().slice(0, 10) }); KOK.save(); toast('Notice published'); rr(); }; }
        };
      },
      staff() {
        return { title: 'Staff', sub: 'Teachers and school leadership', html: `<div class="panel"><div class="tw"><table><thead><tr><th>ID</th><th>Name</th><th>Role</th><th>Section</th></tr></thead><tbody>
        ${db().staff.map(s => `<tr><td>${s.id}</td><td><b>${s.name}</b></td><td>${s.role}</td><td>${s.sec === 'all' ? 'Whole school' : s.sec === 'primary' ? 'Primary' : 'College'}</td></tr>`).join('')}
        ${db().teachers.map(s => `<tr><td>${s.id}</td><td><b>${s.name}</b></td><td>${s.title}</td><td>${s.sec === 'primary' ? 'Primary' : 'College'}</td></tr>`).join('')}</tbody></table></div></div>` };
      }
    }
  };

  const ROLES = { student, parent, teacher, admin };
  const SHORT = { 'Pay School Fees': 'Pay Fees', 'Fees and Payments': 'Fees', 'Results Control': 'Results', 'My Subjects': 'Subjects', 'Payment History': 'History', 'School Fees': 'Fees', 'Score Entry': 'Scores', 'My Classes': 'Classes', 'Announcements': 'Notices', 'Applications': 'Applicants' };
  function cardTables(root) {
    $$('table', root).forEach(t => {
      const hs = [...t.querySelectorAll('thead th')].map(h => h.textContent.trim()); if (!hs.length) return; t.classList.add('rt');
      t.querySelectorAll('tbody tr').forEach(tr => [...tr.children].forEach((td, i) => { td.dataset.l = td.colSpan > 1 ? '' : (hs[i] || ''); }));
    });
  }
  function start(role) {
    const u = KOK.user(); if (!u || u.role !== role) { location.href = 'portal.html'; return; }
    const me = KOK.who(u), cfg = ROLES[role]; document.body.classList.add('dash');
    const roleLabel = { student: me.cls, parent: 'Parent', teacher: me.title, admin: me.role }[role];
    const main = cfg.nav.slice(0, 4), rest = cfg.nav.slice(4);
    $('#app').innerHTML = `<div class="app"><aside class="side" id="side"><a class="brand" href="index.html">${CREST(36)}<div><span>King of Kings</span><small>${cfg.title}</small></div></a>
      <nav>${cfg.nav.map(([k, i, t]) => `<a href="#${k}" data-k="${k}">${i} ${t}</a>`).join('')}<a href="index.html">🌐 School website</a></nav>
      <div class="me"><div class="av">${initials(me.name)}</div><div style="flex:1;min-width:0"><b>${me.name}</b><small>${roleLabel}</small></div></div>
      <button class="btn btn-ghost btn-sm btn-block" style="margin-top:10px" id="lo">Sign out</button></aside>
      <main class="main"><header class="appbar"><a class="brand" href="index.html">${CREST(32)}<div><span>King of Kings</span><small>${cfg.title}</small></div></a><button class="av" id="avb" aria-label="Account menu">${initials(me.name)}</button></header><div id="view"></div></main></div>
      <nav class="tabbar" aria-label="Portal navigation">${main.map(([k, i, t]) => `<a href="#${k}" data-k="${k}"><span>${i}</span>${SHORT[t] || t}</a>`).join('')}<a id="moreb" role="button"><span>☰</span>More</a></nav>
      <div class="sheet-bg" id="sbg"></div>
      <div class="sheet" id="sheet"><div class="grab"></div><div class="me"><div class="av">${initials(me.name)}</div><div style="flex:1;min-width:0"><b>${me.name}</b><small>${roleLabel}</small></div></div>
        ${rest.map(([k, i, t]) => `<a href="#${k}" data-k="${k}"><span class="ico">${i}</span>${t}</a>`).join('')}
        <a href="index.html"><span class="ico">🌐</span>School website</a>
        <button class="row" id="inst" style="display:none"><span class="ico">📲</span>Install app on this phone</button>
        <button class="row" id="lo2"><span class="ico">🚪</span>Sign out</button></div>`;
    const sheet = open => { $('#sheet').classList.toggle('on', open); $('#sbg').classList.toggle('on', open); };
    $('#lo').onclick = $('#lo2').onclick = KOK.logout; $('#moreb').onclick = $('#avb').onclick = () => sheet(true); $('#sbg').onclick = () => sheet(false);
    $$('#sheet a').forEach(a => a.addEventListener('click', () => sheet(false)));
    const inst = $('#inst'); const showInst = () => { if (KOK_APP.standalone) return; if (KOK_APP.can()) { inst.style.display = 'flex'; inst.onclick = () => KOK_APP.install(); } else if (KOK_APP.ios) { inst.style.display = 'flex'; inst.onclick = () => { sheet(false); toast('On iPhone: tap Share, then Add to Home Screen'); }; } };
    showInst(); document.addEventListener('kok-installable', showInst);
    $('#modal').onclick = e => { if (e.target.id === 'modal') closeModal(); };
    const render = () => {
      const k = location.hash.slice(1) || cfg.nav[0][0]; const key = cfg.views[k] ? k : cfg.nav[0][0]; const fn = cfg.views[key];
      $$('[data-k]').forEach(a => a.classList.toggle('on', a.dataset.k === key));
      $('#moreb').classList.toggle('on', rest.some(r => r[0] === key));
      sheet(false);
      const v = fn(me, render);
      $('#view').innerHTML = `<div class="top"><div><h1>${v.title}</h1><div class="sub">${v.sub || ''}</div></div><div class="sw"><span class="pill">📅 ${db().session} · ${db().term}</span></div></div>${v.html}`;
      v.bind && v.bind($('#view')); cardTables($('#view')); scrollTo(0, 0);
    };
    window.addEventListener('hashchange', render); render();
  }
  return { start };
})();
