# King of Kings International School: Website and Portal Prototype

A clickable prototype of the school website with portals for parents, students, teachers and school leadership. It runs fully in the browser. All data shown is sample data kept in your own browser.

## How to open it on a laptop (Windows)

Easiest way:
1. Extract the zip file so you can see this README and the file called index.html.
2. Double click start.bat. A black window opens and your browser loads the site at http://localhost:8080.
3. Leave the black window open while you use the site. Press Ctrl and C in it, or close it, to stop.

If start.bat does not work, do it by hand:
1. Open the extracted folder in File Explorer, click the address bar, type cmd and press Enter.
2. Type: py -m http.server 8080 (if that fails, try: python -m http.server 8080).
3. Open Chrome and go to http://localhost:8080

Python must be installed. Get it from python.org if needed. Node users can run: npx serve -l 8080

Double clicking index.html also shows the pages, but use the steps above for the best result.

## How to open it on a phone

1. Keep the laptop server running and connect the phone to the same wifi.
2. On the laptop, open a command window and type ipconfig. Note the IPv4 Address, for example 192.168.1.5.
3. On the phone, open Chrome or Safari and go to http://192.168.1.5:8080 using your own number.
4. If it will not load, allow Python through the Windows firewall on private networks.

## Demo logins

Open portal.html (the Portal Login button). Pick Primary School or College, then a role. The password for every account is demo123.

Parent: par1 (two children), par2, par3
Student: KKI/P/001 (Primary 4), KKI/C/001 (JSS 2)
Teacher: T001 (Primary), T003 (College)
Leadership: HT01 Head Teacher, PR01 Principal, BU01 Bursar, PO01 Proprietor

## What to try

1. Parent: sign in as par1, open Pay School Fees, choose items, pay by card, and see the receipt.
2. Leadership: sign in as BU01 and open Fees and Payments. The payment from step 1 appears there.
3. Teacher: sign in as T001, open Score Entry, change a score and save.
4. Leadership: open Results Control to publish or hide results. Students and parents only see published results.
5. Website: submit the Admissions form, then see it under Applications in the leadership dashboard.

Use Reset demo data on the login page to return to the starting sample data.

## Folder guide

index.html, about.html, academics.html, admissions.html, gallery.html, news.html, contact.html: public website
portal.html: login page for all portals
student.html, parent.html, teacher.html, admin.html: dashboards
assets/css/style.css: all styling (light green with soft pink)
assets/js/app.js: shared navigation, sample data and storage
assets/js/portal.js: dashboard screens and logic
assets/img: school photos and crest
manifest.webmanifest and sw.js: let the portal be installed as a phone app (works when served from a web address)

## Important notes

This is a prototype. Payments are simulated and no money moves. Data is stored only in the browser being used, so a payment made on one device does not appear on another. A live version needs a real database, secure sign in, and a payment gateway such as Paystack or Flutterwave.

Fees, staff names, student names and scores are sample data and should be replaced with the school's real records.

This copy uses the school's real name and photos. Keep it on your own devices and show it in person. Publish the final site only on hosting the school owns or has approved.

Prototype designed by GloxadX.
