@echo off
cd /d "%~dp0"
echo Starting the King of Kings portal at http://localhost:8080
echo Keep this window open. Close it to stop the site.
start "" /b cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8080"
where py >nul 2>nul
if %errorlevel%==0 (
  py -m http.server 8080
) else (
  python -m http.server 8080
)
echo.
echo The server stopped. If you saw an error, install Python from python.org and try again.
pause
